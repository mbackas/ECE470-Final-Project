% Copyright 2006-2017 Coppelia Robotics GmbH. All rights reserved. 
% marc@coppeliarobotics.com
% www.coppeliarobotics.com
% 
% -------------------------------------------------------------------
% THIS FILE IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
% WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
% AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
% DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
% MISUSING THIS SOFTWARE.
% 
% You are free to use/modify/distribute this file for whatever purpose!
% -------------------------------------------------------------------
%
% This file was automatically created for V-REP release V3.4.0 rev. 1 on April 5th 2017

% Make sure to have the server side running in V-REP: 
% in a child script of a V-REP scene, add following command
% to be executed just once, at simulation start:
%
% simExtRemoteApiStart(19999)
%
% then start simulation, and run this program.
%
% IMPORTANT: for each successful call to simxStart, there
% should be a corresponding call to simxFinish at the end!

function simpleTest()
    disp('Program started');
    vrep=remApi('remoteApi');%,'extApi.h'); % using the header (requires a compiler)
    vrep=remApi('remoteApi.dylib'); % using the prototype file (remoteApiProto.m)
    vrep.simxFinish(-1); % just in case, close all opened connections
    clientID = vrep.simxStart('127.0.0.1', 19997, True, True, 5000, 5);
    if(clientID == -1)
        raise Exception('Failed connecting to remote API server')
    end
    if (clientID>-1)
        disp('Connected to remote API server');
    % Close all open connections (just in case)
    vrep.simxFinish(-1)

% Connect to V-REP (raise exception on failure)
clientID = vrep.simxStart('127.0.0.1', 19997, True, True, 5000, 5);
if clientID == -1
    raise Exception('Failed connecting to remote API server')
end
% Get "handle" to the first joint of robot
result, joint_one_handle = vrep.simxGetObjectHandle(clientID, 'UR3_joint1', vrep.simx_opmode_blocking);
if (result ~= vrep.simx_return_ok)
    raise Exception('could not get object handle for first joint')
end
% Get "handle" to the second joint of robot
result, joint_two_handle = vrep.simxGetObjectHandle(clientID, 'UR3_joint2', vrep.simx_opmode_blocking);
if (result ~= vrep.simx_return_ok)
    raise Exception('could not get object handle for second joint')
end
% Get "handle" to the third joint of robot
result, joint_three_handle = vrep.simxGetObjectHandle(clientID, 'UR3_joint3', vrep.simx_opmode_blocking);
if (result ~= vrep.simx_return_ok)
    raise Exception('could not get object handle for third joint')
end
% Get "handle" to the fourth joint of robot
result, joint_four_handle = vrep.simxGetObjectHandle(clientID, 'UR3_joint4', vrep.simx_opmode_blocking);
if(result ~= vrep.simx_return_ok)
    raise Exception('could not get object handle for fourth joint')
end
% Get "handle" to the fifth joint of robot
result, joint_five_handle = vrep.simxGetObjectHandle(clientID, 'UR3_joint5', vrep.simx_opmode_blocking);
if(result ~= vrep.simx_return_ok)
    raise Exception('could not get object handle for fifth joint')
end
% Get "handle" to the sixth joint of robot
result, joint_six_handle = vrep.simxGetObjectHandle(clientID, 'UR3_joint6', vrep.simx_opmode_blocking);
if(result ~= vrep.simx_return_ok)
    raise Exception('could not get object handle for sixth joint')
end

% Start simulation
vrep.simxStartSimulation(clientID, vrep.simx_opmode_oneshot)

% Wait two seconds
time.sleep(2)

% Get the current value of the first joint variable
result, theta1 = vrep.simxGetJointPosition(clientID, joint_one_handle, vrep.simx_opmode_blocking);
if(result ~= vrep.simx_return_ok)
    raise(Exception('could not get first joint variable'))
end
% print('current value of first joint variable: theta = ',theta1)

result, theta2 = vrep.simxGetJointPosition(clientID, joint_two_handle, vrep.simx_opmode_blocking);
if(result ~= vrep.simx_return_ok)
    raise(Exception('could not get first joint variable'))
end
% print('current value of first joint variable: theta = {:f}'.format(theta2))

result, theta3 = vrep.simxGetJointPosition(clientID, joint_three_handle, simx_opmode_blocking);
if(result ~= vrep.simx_return_ok)
    raise Exception('could not get first joint variable')
end
% print('current value of first joint variable: theta = {:f}'.format(theta3))

result, theta4 = vrep.simxGetJointPosition(clientID, joint_four_handle, vrep.simx_opmode_blocking);
if(result ~= vrep.simx_return_ok)
    raise Exception('could not get first joint variable')
end
% print('current value of first joint variable: theta = {:f}'.format(theta4))

result, theta5 = vrep.simxGetJointPosition(clientID, joint_five_handle, vrep.simx_opmode_blocking);
if(result ~= vrep.simx_return_ok)
    raise(Exception('could not get first joint variable'))
end
% print('current value of first joint variable: theta = {:f}'.format(theta5))

result, theta6 = vrep.simxGetJointPosition(clientID, joint_six_handle, vrep.simx_opmode_blocking);
if(result ~= vrep.simx_return_ok)
    raise(Exception('could not get first joint variable'))
end
% print('current value of first joint variable: theta = {:f}'.format(theta6))
% Set the desired value of the first joint variable
vrep.simxSetJointTargetPosition(clientID, joint_one_handle, theta1 + (PI / 2), vrep.simx_opmode_oneshot)
time.sleep(2)
% Set the desired value of the first joint variable
vrep.simxSetJointTargetPosition(clientID, joint_two_handle, theta2 + -(PI / 2), vrep.simx_opmode_oneshot)
time.sleep(2)
% Set the desired value of the first joint variable
vrep.simxSetJointTargetPosition(clientID, joint_three_handle, theta3 + (PI / 2), vrep.simx_opmode_oneshot)
time.sleep(2)
% Set the desired value of the first joint variable
vrep.simxSetJointTargetPosition(clientID, joint_four_handle, theta4 + (PI / 2), vrep.simx_opmode_oneshot)
time.sleep(2)
% Set the desired value of the first joint variable
vrep.simxSetJointTargetPosition(clientID, joint_five_handle, theta5 + (PI / 2), vrep.simx_opmode_oneshot)
time.sleep(2)
% Set the desired value of the first joint variable
vrep.simxSetJointTargetPosition(clientID, joint_six_handle, theta6 + (PI / 2), vrep.simx_opmode_oneshot)

result, theta3 = vrep.simxGetJointPosition(clientID, joint_three_handle, vrep.simx_opmode_blocking);

vrep.simxSetJointTargetPosition(clientID, joint_three_handle, theta3 - (PI / 2), vrep.simx_opmode_oneshot)

result, theta1 = vrep.simxGetJointPosition(clientID, joint_one_handle, vrep.simx_opmode_blocking);

time.sleep(1)
vrep.simxSetJointTargetPosition(clientID, joint_one_handle, theta1 + (PI), vrep.simx_opmode_oneshot)





% Wait two seconds
time.sleep(5)

% Get the current value of the first joint variable
result, theta = vrep.simxGetJointPosition(clientID, joint_one_handle, vrep.simx_opmode_blocking);
if(result ~= vrep.simx_return_ok)
    raise Exception('could not get first joint variable')
end
% print('current value of first joint variable: theta = {:f}'.format(theta))

% Stop simulation
vrep.simxStopSimulation(clientID, vrep.simx_opmode_oneshot)

% Before closing the connection to V-REP, make sure that the last command sent out had time to arrive. You can guarantee this with (for example):
vrep.simxGetPingTime(clientID)

% Close the connection to V-REP
vrep.simxFinish(clientID)
        
        
        % Now close the connection to V-REP:    
        vrep.simxFinish(clientID);
    else
        disp('Failed connecting to remote API server');
    end
    vrep.delete(); % call the destructor!
    
    disp('Program ended');
end
